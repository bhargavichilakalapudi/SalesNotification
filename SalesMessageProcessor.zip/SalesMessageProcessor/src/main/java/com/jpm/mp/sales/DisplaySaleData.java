package com.jpm.mp.sales;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Logs the output
 *
 */
public class DisplaySaleData {

	private HashMap<String, Product> lineItems = new HashMap<String, Product>();

	private double totalSalesValue;

	private ArrayList<String> salesMsgList;

	private ArrayList<String> adjustmentReports;

	public DisplaySaleData() {
		this.salesMsgList = new ArrayList<String>();
		this.adjustmentReports = new ArrayList<String>();
		this.totalSalesValue = 0.0;
	}

	//If product is not present in map it creates a new object else retrieves the existing object
	public Product getProduct(String type) {
		return lineItems.getOrDefault(type, new Product(type));
	}

	public void updateProduct(Product product) {
		lineItems.put(product.getProductType(), product);
	}

	public ArrayList<String> getNormalReports() {
		return salesMsgList;
	}

	public void setNormalReports(String normalReport) {
		this.salesMsgList.add(normalReport);
	}

	public ArrayList<String> getAdjustmentReports() {
		return adjustmentReports;
	}

	public void setAdjustmentReports(String adjustmentReport) {
		this.adjustmentReports.add(adjustmentReport);
	}

	public double getTotalSalesValue() {
		return totalSalesValue;
	}


	public void setTotalSalesValue(double productTotalPrice) {
		totalSalesValue = productTotalPrice;
	}

	/*
	 * Report outputs sales information to system console on every 10th report
	 * iteration using modulo. Displays in a table formatted structure and stops
	 * execution of the application after 50th message iteration.
	 */
	public void buildReport() {

		if (null != salesMsgList && (salesMsgList.size() % 10) == 0) {
			setTotalSalesValue(0.0);
			System.out.println();
			System.out.println("Generating the Sale report for 10 transactions");
			System.out.println("|Product type        |Quantity   |Value      |");
			System.out.println("------------------------------------------------");
			lineItems.forEach((k, v) -> formatReports(k, v));
			System.out.println("------------------------------------------------");
			System.out.println("Completed 10 Transctions List");
		}

		if ((salesMsgList.size() % 50) == 0 && salesMsgList.size() != 0) {
			System.out.println(
					"Application reached 50 messages and cannot process further. The following are the adjustment made in price;\n");

			getAdjustmentReports().forEach(System.out::println);
			System.exit(1);
		}
	}

	public void formatReports(String type, Product product) {
		String lineItem = String.format("|%-18s|%-11d|%-11.2f|", product.getProductType(), product.getTotalQuantity(),
				product.getTotalPrice());
		System.out.println(lineItem);
	}
}
