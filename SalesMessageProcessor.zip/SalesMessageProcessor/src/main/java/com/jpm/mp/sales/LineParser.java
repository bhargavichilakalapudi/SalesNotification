package com.jpm.mp.sales;

/**
 * Parse the input msg and dIfferentiate the 3 incoming messages and store the details 
 *
 */
public class LineParser {
	private String productType;
	private double productCost;
	private int productQty;
	private String adjOperator;
	private double adjProductPrice;

	public LineParser(String line) {
		this.productType = "";
		this.productCost = 0.0;
		this.productQty = 0;
		this.adjOperator = "";
		this.adjProductPrice=0.0;
		parseEachLine(line);
	}

	public LineParser() {
		// TODO Auto-generated constructor stub
	}

	public boolean parseEachLine(String line) {

		if (null == line || line.isEmpty()) {
			return false;
		}
		String[] arr = line.trim().split(" ");
		String startWord = arr[0];
		if (startWord.matches("Add|Subtract|Multiply")) {
			return parseSaleAdj3rdLine(arr);
		} else if (arr.length == 7) {
			return parse2ndLine(arr);
		} else if (arr.length == 3) {
			return parseProductType1stLine(arr);
		} else {
			System.out.println("Invalid sale notification recieved and the notification is "+ line);
		}
		return true;
	}

	private boolean parseProductType1stLine(String[] lineArr) {
		productType = lineArr[0];
		productCost = parsePrice(lineArr[2]);
		productQty = 0; 
		return true;
	}

	private boolean parse2ndLine(String[] lineArr) {
		productType = lineArr[3];
		productCost = parsePrice(lineArr[5]);
		productQty = Integer.parseInt(lineArr[0]);
		return true;
	}

	private boolean parseSaleAdj3rdLine(String[] lineArr) {
		if (lineArr.length != 3)
			return false;
		adjOperator = lineArr[0];
		productType = lineArr[2];
		productQty = 0;
		adjProductPrice = parsePrice(lineArr[1]);
		return true;
	}


	public double parsePrice(String pricewithp) {
		double price = Double.parseDouble(pricewithp.replace("p", ""));
		return price;
	}

	public String getProductType() {
		return productType;
	}

	public double getProductPrice() {
		return productCost;
	}

	public String getOperatorType() {
		return adjOperator;
	}

	public int getProductQuantity() {
		return productQty;
	}

	public double getAdjProductPrice() {
		return adjProductPrice;
	}


}
