package com.jpm.mp.sales.test;

import java.io.IOException;

import org.junit.Test;

import com.jpm.mp.sales.LineParser;
import com.jpm.mp.sales.SalesMsgProcessor;

import junit.framework.Assert;

public class TestSalesRecords {
	
	@Test
	public void readSalesMessage() throws IOException{
		SalesMsgProcessor salesMsgProcessor = new SalesMsgProcessor();
		salesMsgProcessor.processNotifications("salesInput.txt");
	}
	@Test(expected = NullPointerException.class)
	public void invalidFilName() throws IOException{
		SalesMsgProcessor salesMsgProcessor = new SalesMsgProcessor();
		salesMsgProcessor.processNotifications("Input.txt");
	}
	@Test(expected = NullPointerException.class)
	public void nullInput() throws IOException{
		SalesMsgProcessor salesMsgProcessor = new SalesMsgProcessor();
		salesMsgProcessor.processNotifications(null);
	}
	
	@Test
	public void emptyNotificationRecieved() throws IOException{
		LineParser lineParser ; 
		Assert.assertFalse(new LineParser().parseEachLine(""));
	}
	
	@Test
	public void nullNotificationRecieved() throws IOException{
		LineParser lineParser ; 
		Assert.assertFalse(new LineParser().parseEachLine(null));

	}

}
