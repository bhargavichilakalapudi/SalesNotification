package com.jpm.mp.sales;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

/**
 * Receives the sales notifications and process it and displays it
 *
 */
public class SalesMsgProcessor {

	public boolean processNotifications(String fileName) throws IOException{
		Sales sales= new Sales();
		boolean validation = false;
		BufferedReader br = readInputFile(fileName);
		String line;
		while ((line = br.readLine()) != null) {
			validation = sales.processInputSalesMessage(line);

			sales.displaySaleData.buildReport();
		}
		return validation;

	}

	private BufferedReader readInputFile(String fileName) throws FileNotFoundException {
		URL resource = ClassLoader.getSystemResource(fileName);
		File file = new File(resource.getFile());
		FileReader reader = new FileReader(file);
		BufferedReader br = new BufferedReader(reader);
		return br;
	}
}
